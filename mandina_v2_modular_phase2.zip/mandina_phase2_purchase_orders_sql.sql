-- Mandina Inventory V2 - Phase 2 Purchase Orders Compatibility Patch
-- Safe: adds missing columns only. Does not delete old data.

alter table public.items
  add column if not exists receiving_unit text,
  add column if not exists cost_unit text;

update public.items
set receiving_unit = coalesce(receiving_unit, purchase_package_type, stock_unit),
    cost_unit = coalesce(cost_unit, secondary_unit, stock_unit)
where receiving_unit is null or cost_unit is null;

alter table public.purchase_orders
  add column if not exists po_number text,
  add column if not exists branch_id text,
  add column if not exists supplier_id uuid,
  add column if not exists status text default 'draft',
  add column if not exists expected_delivery_date date,
  add column if not exists delivery_asap boolean default false,
  add column if not exists notes text,
  add column if not exists total_amount numeric default 0,
  add column if not exists created_by uuid,
  add column if not exists approved_by uuid,
  add column if not exists created_at timestamptz default now(),
  add column if not exists updated_at timestamptz default now(),
  add column if not exists approved_at timestamptz;

alter table public.purchase_order_lines
  add column if not exists purchase_order_id uuid,
  add column if not exists item_id uuid,
  add column if not exists ordered_qty numeric default 0,
  add column if not exists unit text,
  add column if not exists cost_unit text,
  add column if not exists unit_price numeric default 0,
  add column if not exists line_total numeric default 0,
  add column if not exists notes text,
  add column if not exists sort_order integer default 0;

create index if not exists idx_purchase_orders_branch_id on public.purchase_orders(branch_id);
create index if not exists idx_purchase_orders_supplier_id on public.purchase_orders(supplier_id);
create index if not exists idx_purchase_order_lines_po_id on public.purchase_order_lines(purchase_order_id);
